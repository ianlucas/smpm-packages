These files are used for testing Get5. You can ignore them or delete the entire "tests" folder. It makes no difference
to your Get5 installation.
